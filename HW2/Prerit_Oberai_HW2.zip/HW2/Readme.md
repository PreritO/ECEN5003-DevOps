This is a work-in progress  example of a multi-container python request and response application for HW2

-- Prerit Oberai

## Usage

1. Navigate to Vagrant Folder on vagrant: 
```bash
- cd /vagrant 
$ docker-compose up

```

2. See whether client is able to send a request to server and print a response 
