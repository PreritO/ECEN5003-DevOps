./confd --confdir ./etcdconfd/ -onetime -backend etcd -node http://localhost:2379
