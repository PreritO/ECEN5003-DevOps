#https://coreos.com/etcd/docs/latest/v2/api.html

curl http://localhost:2379/v2/members | jq

curl -L http://127.0.0.1:2379/version

curl http://127.0.0.1:2379/v2/keys/message -XPUT -d value="Hello world"

curl http://127.0.0.1:2379/v2/keys/message 

curl http://127.0.0.1:2379/v2/keys/message -XDELETE
