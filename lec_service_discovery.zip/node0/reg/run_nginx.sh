#!/bin/bash
sudo docker run --rm -d -p :80 -e "SERVICE_NAME=nginx" nginx
