#!/bin/bash

# START CLUSTER WITH ONE SERVER
export HostIP="192.168.33.12"

sudo docker run --rm -d -v /usr/share/ca-certificates/:/etc/ssl/certs \
     -p 2380:2380 -p 2379:2379 -p 4001:4001  \
     --name etcd quay.io/coreos/etcd:v2.3.8  \
     -name etcd2 \
     -advertise-client-urls http://${HostIP}:2379 \
     -listen-client-urls http://0.0.0.0:2379  \
     -initial-advertise-peer-urls http://${HostIP}:2380  \
     -listen-peer-urls http://0.0.0.0:2380  \
     -initial-cluster-token etcd-cluster-1  \
     -initial-cluster etcd0=http://192.168.33.10:2380,etcd1=http://192.168.33.11:2380,etcd2=http://192.168.33.12:2380  \
     -initial-cluster-state new



